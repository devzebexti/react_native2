import React, { Component,useState } from 'react';
import { Dropdown } from 'react-native-material-dropdown';
import { TouchableOpacity, Text, View,StyleSheet,TextInput,Animated,Alert,Switch,ScrollView} from 'react-native';
import {Picker} from '@react-native-picker/picker';
import { Actions } from 'react-native-router-flux';
import Logo from '../components/Logo';
import DatePicker from 'react-native-datepicker';

const getCurrentDate=()=>{

   var date = new Date().getDate();
   var month = new Date().getMonth() + 1;
   var year = new Date().getFullYear();

   //Alert.alert(date + '-' + month + '-' + year);
   // You can turn it in to your desired format
   console.log(year+ '-' +  month + '-' +date);
   return year+ '-' +  month + '-' +date;//format: dd-mm-yyyy;
}
export default class LetterofTransmittal extends Component<{}> {
   constructor(props) {
      super(props);
      this.state = {permitapplication:'',special_instructions:'',date:getCurrentDate(),letterdate:'',email_address:'',project_reference:'',Planning:'',Zoning:'',Engineering:'',Fire:'',WaterSewer:'',Drainage:'',Landscape:'',CRA:'',Structural:'',Electrical:'',Plumbing:'',Mechanical:'',ReserveCapacityChanges:'',From:'',address:'',emailaddress:'',contact:'',phone:'',fax:'',HandDelivery:'',PostalDelivery:'',DropDelivery:'',SpecialDelivery:'',EmailDelivery:'',Initial:'',Corrected:'',Revised:'',shopdrawings:'',structuralsteel:'',woodtrusses:'',glassglazing:'',productapprovals:'',fireprotection:'',Other:'',spotsurvey:'',finalsurvey:'',energy:'',specialinspectorletter:'',soilreports:'',inspectionreports:'',energycalcs:'',siteplans:'',othertwo:'',pilelogs:'',condoapproval:'',turtleglass:'',windloads:'',subpermit:'',outsideagencies:'',ArchitecturalSheet:'',FireSheet:'',StructuralSheet:'',ZoningSheet:'',ElectricalSheet:'',EngineeringSheet:'',MechanicalSheet:'',RCCSheet:'',PlumbingSheet:'',DrainageSheet:'',WaterSheet:'',SewerSheet:'',CRASheet:'',LandscapeSheet:'',special_instructions:''};
   }
   callSignup = async () => {
      this.setState({isShowingLoader: true});
      try{
         const formData = new FormData();
         formData.append('method', 'letteroftrasmittal');
         formData.append('letter_date', this.state.letterdate);
         formData.append('email_address', this.state.email_address);
         formData.append('project_reference', this.state.project_reference);
         formData.append('Planning', this.state.Planning);
         formData.append('Zoning', this.state.Zoning);
         formData.append('Engineering', this.state.Engineering);
         formData.append('Fire', this.state.Fire);
         formData.append('Water_Sewer', this.state.WaterSewer);
         formData.append('Drainage', this.state.Drainage);
         formData.append('Landscape', this.state.Landscape);
         formData.append('CRA', this.state.CRA);
         formData.append('Structural', this.state.Structural);
         formData.append('Electrical', this.state.Electrical);
         formData.append('Plumbing', this.state.Plumbing);
         formData.append('Mechanical', this.state.Mechanical);
         formData.append('ReserveCapacityChanges', this.state.ReserveCapacityChanges);
         formData.append('letterfrom', this.state.From);
         formData.append('address', this.state.address);

         formData.append('emailaddress', this.state.emailaddress);
         formData.append('contact', this.state.contact);
         formData.append('phone', this.state.phone);

         formData.append('fax', this.state.fax);
         formData.append('HandDelivery', this.state.HandDelivery);
         formData.append('PostalDelivery', this.state.PostalDelivery);

         formData.append('DropDelivery', this.state.DropDelivery);

         formData.append('SpecialDelivery', this.state.SpecialDelivery);
         formData.append('EmailDelivery', this.state.EmailDelivery);

         formData.append('Initial', this.state.Initial);
         formData.append('Corrected', this.state.Corrected);
         formData.append('Revised', this.state.Revised);

         formData.append('shopdrawings', this.state.shopdrawings);
         formData.append('structuralsteel', this.state.structuralsteel);

         formData.append('woodtrusses', this.state.woodtrusses);
         formData.append('glassglazing', this.state.glassglazing);
         formData.append('productapprovals', this.state.productapprovals);

         formData.append('fireprotection', this.state.fireprotection);
         formData.append('Other', this.state.Other);

         formData.append('spotsurvey', this.state.spotsurvey);
         formData.append('finalsurvey', this.state.finalsurvey);
         formData.append('energy', this.state.energy);

         formData.append('specialinspectorletter', this.state.specialinspectorletter);
         formData.append('soilreports', this.state.soilreports);
         formData.append('inspectionreports', this.state.inspectionreports);
         formData.append('energycalcs', this.state.energycalcs);
         formData.append('siteplans', this.state.siteplans);
         formData.append('othertwo', this.state.othertwo);
         formData.append('pilelogs', this.state.pilelogs);
         formData.append('condoapproval', this.state.condoapproval);

         formData.append('turtleglass', this.state.turtleglass);
         formData.append('windloads', this.state.windloads);
         formData.append('subpermit', this.state.subpermit);
         formData.append('outsideagencies', this.state.outsideagencies);
         formData.append('planssubmitted', this.state.planssubmitted);
         formData.append('architecturalsheet', this.state.ArchitecturalSheet);
         formData.append('firesheet', this.state.FireSheet);
         formData.append('structuralsheet', this.state.StructuralSheet);
         formData.append('zoningsheet', this.state.ZoningSheet);
         formData.append('ElectricalSheet', this.state.ElectricalSheet);
         formData.append('EngineeringSheet', this.state.EngineeringSheet);
         formData.append('MechanicalSheet', this.state.MechanicalSheet);
         formData.append('RCCSheet', this.state.RCCSheet);
         formData.append('PlumbingSheet', this.state.PlumbingSheet);
         formData.append('DrainageSheet', this.state.DrainageSheet);
         formData.append('WaterSheet', this.state.WaterSheet);
         formData.append('SewerSheet', this.state.SewerSheet);
         formData.append('CRASheet', this.state.CRASheet);
         formData.append('LandscapeSheet', this.state.LandscapeSheet);
         formData.append('SpecialInstructions', this.state.special_instructions);

         axios({
           url    : 'https://miamidata.com/mvpapi/webservices.php',
           method : 'POST',
           data   : formData,
           headers: {
                  Accept: 'application/json',
                  'Content-Type': 'multipart/form-data'
               }
            })
            .then(function (response) {
                  //console.log("response :", response);
                  //console.log("responseid :", response.data.userid);
                  //this.setState({ articleId: response.data.id });
                  Alert.alert(
                     'Message',
                     response.data.message,
                     [
                        {text: 'OK', onPress: () => ''},
                     ],
                     {cancelable: false},
                  )   
            })
            .catch(function (error) {
                  console.log("error from image :");
            })
      } catch (error) {
          console.log(error);
          this.setState({isShowingLoader: false});
          Alert.alert(
              'Error',
              'Something went wrong!',
              [
              {text: 'OK', onPress: () => console.log('OK Pressed')},
              ],
              {cancelable: false},
          )
      }
 }
   togglePlanning = (value) => {
      this.setState({Planning: value})
   }
   toggleZoning = (value)=>{
      this.setState({Zoning: value})
   }
   toggleEngineering = (value)=>{
      this.setState({Engineering: value})
   }
   toggleFire = (value)=>{
      this.setState({Fire: value})
   }
   toggleWaterSewer = (value)=>{
      this.setState({WaterSewer: value})
   }
   toggleDrainage = (value)=>{
      this.setState({Drainage: value})
   }
   toggleLandscape = (value)=>{
      this.setState({Landscape: value})
   }
   toggleCRA = (value)=>{
      this.setState({CRA: value})
   }
   toggleStructural = (value)=>{
      this.setState({Structural: value})
   }
   toggleElectrical = (value)=>{
      this.setState({Electrical: value})
   }
   togglePlumbing = (value)=>{
      this.setState({Plumbing: value})
   }
   toggleMechanical = (value)=>{
      this.setState({Mechanical: value})
   }
   toggleReserveCapacityChanges = (value)=>{
      this.setState({ReserveCapacityChanges: value})
   }
   toggleHandDelivery = (value)=>{
      this.setState({HandDelivery: value})
   }
   togglePostalDelivery = (value)=>{
      this.setState({PostalDelivery: value})
   }
   toggleDropDelivery = (value)=>{
      this.setState({DropDelivery: value})
   }
   toggleSpecialDelivery = (value)=>{
      this.setState({SpecialDelivery: value})
   }
   toggleEmailDelivery = (value)=>{
      this.setState({EmailDelivery: value})
   }
   toggleInitial = (value)=>{
      this.setState({Initial: value})
   }
   toggleCorrected = (value)=>{
      this.setState({Corrected: value})
   }
   toggleRevised = (value)=>{
      this.setState({Revised: value})
   }
   toggleshopdrawings = (value)=>{
      this.setState({shopdrawings: value})
   }
   togglestructuralsteel = (value)=>{
      this.setState({structuralsteel: value})
   }
   togglewoodtrusses = (value)=>{
      this.setState({woodtrusses: value})
   }
   toggleglassglazing = (value)=>{
      this.setState({glassglazing: value})
   }
   toggleproductapprovals = (value)=>{
      this.setState({productapprovals: value})
   }
   togglefireprotection = (value)=>{
      this.setState({fireprotection: value})
   }
   toggleOther = (value)=>{
      this.setState({Other: value})
   }
   togglespotsurvey = (value)=>{
      this.setState({spotsurvey: value})
   }
   togglefinalsurvey = (value)=>{
      this.setState({finalsurvey: value})
   }
   toggleenergy = (value)=>{
      this.setState({energy: value})
   }
   togglespecialinspectorletter = (value)=>{
      this.setState({specialinspectorletter: value})
   }
   togglesoilreports = (value)=>{
      this.setState({soilreports: value})
   }
   toggleinspectionreports = (value)=>{
      this.setState({inspectionreports: value})
   }
   toggleenergycalcs = (value)=>{
      this.setState({energycalcs: value})
   }
   togglesiteplans = (value)=>{
      this.setState({siteplans: value})
   }
   toggleothertwo = (value)=>{
      this.setState({othertwo: value})
   }
   togglepilelogs = (value)=>{
      this.setState({pilelogs: value})
   }
   togglecondoapproval = (value)=>{
      this.setState({condoapproval: value})
   }
   toggleturtleglass = (value)=>{
      this.setState({turtleglass: value})
   }
   togglewindloads = (value)=>{
      this.setState({windloads: value})
   }
   togglesubpermit = (value)=>{
      this.setState({subpermit: value})
   }
   toggleoutsideagencies = (value)=>{
      this.setState({outsideagencies: value})
   }
   toggleArchitecturalSheet = (value)=>{
      this.setState({ArchitecturalSheet: value})
   }
   toggleFireSheet = (value)=>{
      this.setState({FireSheet: value})
   }
   toggleStructuralSheet = (value)=>{
      this.setState({StructuralSheet: value})
   }
   toggleZoningSheet = (value)=>{
      this.setState({ZoningSheet: value})
   }
   toggleElectricalSheet = (value)=>{
      this.setState({ElectricalSheet: value})
   }
   toggleEngineeringSheet = (value)=>{
      this.setState({EngineeringSheet: value})
   }
   toggleMechanicalSheet = (value)=>{
      this.setState({MechanicalSheet: value})
   }
   toggleRCCSheet = (value)=>{
      this.setState({RCCSheet: value})
   }
   togglePlumbingSheet = (value)=>{
      this.setState({PlumbingSheet: value})
   }
   toggleDrainageSheet = (value)=>{
      this.setState({DrainageSheet: value})
   }
   toggleWaterSheet = (value)=>{
      this.setState({WaterSheet: value})
   }
   toggleSewerSheet = (value)=>{
      this.setState({SewerSheet: value})
   }
   toggleCRASheet = (value)=>{
      this.setState({CRASheet: value})
   }
   toggleLandscapeSheet = (value)=>{
      this.setState({LandscapeSheet: value})
   }
   render() {
      

      return (
         <ScrollView>
         <View style={styles.container}>
            <View style={styles.datepickerwarraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(letterdate) => this.setState({letterdate})}  
                     placeholder="Letter Date"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.letterdate.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(email_address) => this.setState({email_address})}  
                     placeholder="Email Address"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.email_address.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(project_reference) => this.setState({project_reference})}  
                     placeholder="Project/Reference"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.project_reference.focus()}
                  />
            </View>   
                  <Text style={styles.clstitletext}>
                     For Review By: (check all applicable spaces)
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch 
                        onValueChange={this.togglePlanning}
                        value={this.state.Planning}
                     />
                     Planning
                  </Text>
                  <Text style={styles.clscheckboxlabel}>  
                     <Switch 
                        onValueChange={this.toggleZoning}
                        value={this.state.Zoning}
                     />
                     Zoning
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch 
                        onValueChange={this.toggleEngineering}
                        value={this.state.Engineering}
                     />
                     Engineering
                  </Text> 
                  <Text style={styles.clscheckboxlabel}>  
                     <Switch 
                        onValueChange={this.toggleFire}
                        value={this.state.Fire}
                     />
                     
                  </Text>
                  <Text style={styles.clscheckboxlabel}>   
                     <Switch 
                        onValueChange={this.toggleWaterSewer}
                        value={this.state.WaterSewer}
                     />
                     Water / Sewer
                  </Text>
                  <Text style={styles.clscheckboxlabel}>     
                     <Switch 
                        onValueChange={this.toggleDrainage}
                        value={this.state.Drainage}
                     />
                     Drainage
                  </Text>
                  <Text style={styles.clscheckboxlabel}>   
                     <Switch 
                        onValueChange={this.toggleLandscape}
                        value={this.state.Landscape}
                     />
                     Landscape
                  </Text>
                  <Text style={styles.clscheckboxlabel}>   
                     <Switch 
                        onValueChange={this.toggleCRA}
                        value={this.state.CRA}
                     />
                     CRA
                  </Text>
                  <Text style={styles.clstitletext}>
                     Discipline:
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleStructural}
                        value={this.state.Structural}
                     />
                     Structural
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleElectrical}
                        value={this.state.Electrical}
                     />
                     Electrical
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglePlumbing}
                        value={this.state.Plumbing}
                     />
                     Plumbing
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleMechanical}
                        value={this.state.Mechanical}
                     />
                     Mechanical
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleReserveCapacityChanges}
                        value={this.state.ReserveCapacityChanges}
                     />
                     Reserve Capacity Changes
                  </Text>
                  
                  <TextInput style={styles.inputBox} 
                     onChangeText={(from) => this.setState({from})}  
                     placeholder="From"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                  />
                  <TextInput style={styles.inputBox} 
                     onChangeText={(address) => this.setState({address})}  
                     placeholder="Address"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                  />
                  <TextInput style={styles.inputBox} 
                     onChangeText={(emailaddress) => this.setState({emailaddress})}  
                     placeholder="Email Address"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="email-address"
                  />
                  <TextInput style={styles.inputBox} 
                     onChangeText={(contact) => this.setState({contact})}  
                     placeholder="Contact"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                  />
                  <TextInput style={styles.inputBox} 
                     onChangeText={(phone) => this.setState({phone})}  
                     placeholder="Phone"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="phone-pad"
                  />
                  <TextInput style={styles.inputBox} 
                     onChangeText={(fax) => this.setState({fax})}  
                     placeholder="Fax"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="phone-pad"
                  />
                  <Text style={styles.clstitletext}>
                     WE ARE SUBMITTING TO YOU
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleHandDelivery}
                        value={this.state.HandDelivery}
                     />
                     Hand Delivery
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglePostalDelivery}
                        value={this.state.PostalDelivery}
                     />
                     Postal Delivery
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleDropDelivery}
                        value={this.state.DropDelivery}
                     />
                     Drop Delivery
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleSpecialDelivery}
                        value={this.state.SpecialDelivery}
                     />
                     Special Delivery
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleEmailDelivery}
                        value={this.state.EmailDelivery}
                     />
                     Email Delivery
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleInitial}
                        value={this.state.Initial}
                     />
                     Initial (original) set of plans
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleCorrected}
                        value={this.state.Corrected}
                     />
                     Corrected (non-permitted) plans
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleRevised}
                        value={this.state.Revised}
                     />
                     Revised (permitted) plans
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleshopdrawings}
                        value={this.state.shopdrawings}
                     />
                     shop drawings
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglestructuralsteel}
                        value={this.state.structuralsteel}
                     />
                     structural steel
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglewoodtrusses}
                        value={this.state.woodtrusses}
                     />
                     wood trusses
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleglassglazing}
                        value={this.state.glassglazing}
                     />
                     glass/glazing
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleproductapprovals}
                        value={this.state.productapprovals}
                     />
                     product approvals
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglefireprotection}
                        value={this.state.fireprotection}
                     />
                     fire protection
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleOther}
                        value={this.state.Other}
                     />
                     Other
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglespotsurvey}
                        value={this.state.spotsurvey}
                     />
                     spot survey
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglefinalsurvey}
                        value={this.state.finalsurvey}
                     />
                     final survey
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleenergy}
                        value={this.state.energy}
                     />
                     energy (insulation) certification
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglespecialinspectorletter}
                        value={this.state.specialinspectorletter}
                     />
                     special inspector letter / form
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglesoilreports}
                        value={this.state.soilreports}
                     />
                     soil reports
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleinspectionreports}
                        value={this.state.inspectionreports}
                     />
                     inspection reports
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleenergycalcs}
                        value={this.state.energycalcs}
                     />
                     energy calcs
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglesiteplans}
                        value={this.state.siteplans}
                     />
                     site plans
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleothertwo}
                        value={this.state.othertwo}
                     />
                     other
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglepilelogs}
                        value={this.state.pilelogs}
                     />
                     pile logs 
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglecondoapproval}
                        value={this.state.condoapproval}
                     />
                     condo/ H.O. approval
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleturtleglass}
                        value={this.state.turtleglass}
                     />
                     turtle glass I.D.
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglewindloads}
                        value={this.state.windloads}
                     />
                     wind loads
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglesubpermit}
                        value={this.state.subpermit}
                     />
                     sub-permit
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleoutsideagencies}
                        value={this.state.outsideagencies}
                     />
                     outside agencies
                  </Text>
                  <Text style={styles.clstitletext}>
                     PLANS SUBMITTED
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleArchitecturalSheet}
                        value={this.state.ArchitecturalSheet}
                     />
                     Architectural Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleFireSheet}
                        value={this.state.FireSheet}
                     />
                     Fire Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleStructuralSheet}
                        value={this.state.StructuralSheet}
                     />
                     Structural Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleZoningSheet}
                        value={this.state.ZoningSheet}
                     />
                     Zoning Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleElectricalSheet}
                        value={this.state.ElectricalSheet}
                     />
                     Electrical Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleEngineeringSheet}
                        value={this.state.EngineeringSheet}
                     />
                     Engineering Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleMechanicalSheet}
                        value={this.state.MechanicalSheet}
                     />
                     Mechanical Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleRCCSheet}
                        value={this.state.RCCSheet}
                     />
                     RCC Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.togglePlumbingSheet}
                        value={this.state.PlumbingSheet}
                     />
                     Plumbing Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleDrainageSheet}
                        value={this.state.DrainageSheet}
                     />
                     Drainage Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleWaterSheet}
                        value={this.state.WaterSheet}
                     />
                     Water Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleSewerSheet}
                        value={this.state.SewerSheet}
                     />
                     Sewer Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleCRASheetl}
                        value={this.state.CRASheet}
                     />
                     CRA Sheet
                  </Text>
                  <Text style={styles.clscheckboxlabel}>
                     <Switch style={styles.clscheckboxval}
                        onValueChange={this.toggleLandscapeSheet}
                        value={this.state.LandscapeSheet}
                     />
                     Landscape Sheet
                  </Text>
                  <TextInput style={styles.inputBox} 
                     onChangeText={(special_instructions) => this.setState({special_instructions})}  
                     placeholder="Special Instructions"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.special_instructions.focus()}
                  />
                  
                  
                  <TouchableOpacity onPress={this.callSignup} style={styles.button}>
                     <Text style={styles.buttonText}>Submit</Text>
                  </TouchableOpacity>
         </View>
         </ScrollView>	
         
      )
   }
}
const styles = StyleSheet.create({
   container : {
      backgroundColor:'#455a64',
      alignItems:'center',
      justifyContent :'center'
   },
   inputBox: {
     width:300,
     height:45,
     backgroundColor:'rgba(255, 255,255,0.2)',
     borderRadius: 15,
     paddingHorizontal:12,
     fontSize:16,
     color:'#ffffff',
     marginVertical: 10
   },
   PickerBox:{
     width:300,
     height:45,
     backgroundColor:'rgba(255, 255,255,0.2)',
     fontSize:16,
     color:'#ffffff',
   },
   button: {
     width:300,
     backgroundColor:'#1c313a',
      borderRadius: 25,
       marginVertical: 10,
       paddingVertical: 13
   },
   buttonText: {
     fontSize:16,
     fontWeight:'500',
     color:'#ffffff',
     textAlign:'center'
   },
   clstitletext:{
      width:300,
      fontSize: 20,
      fontWeight: "bold",
      color:'#FFFFFF',
   },
   clscheckboxlabel:{
      width:300,
      fontSize: 18,
      color:'#FFFFFF',
      padding:"2%"
   },
   datepickerwarraper:{
      marginTop:"3%",
      marginBottom:"3%",
      color:'#FFFFFF',
   },
   datepickerinput:{
      width:300,
      color:'#FFFFFF',
   }
   
 });