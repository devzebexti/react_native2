import React, { Component,useState } from 'react';
import { Dropdown } from 'react-native-material-dropdown';
import { TouchableOpacity, Text, View,StyleSheet,TextInput,Animated,Alert,Switch,ScrollView} from 'react-native';
import {Picker} from '@react-native-picker/picker';
import { Actions } from 'react-native-router-flux';
import Logo from '../components/Logo';
import DatePicker from 'react-native-datepicker';

const getCurrentDate=()=>{

   var date = new Date().getDate();
   var month = new Date().getMonth() + 1;
   var year = new Date().getFullYear();

   //Alert.alert(date + '-' + month + '-' + year);
   // You can turn it in to your desired format
   console.log(year+ '-' +  month + '-' +date);
   return year+ '-' +  month + '-' +date;//format: dd-mm-yyyy;
}
export default class Datachangehollywood extends Component<{}> {
   constructor(props) {
      super(props);
      this.state = {permitapplication:'',job_name:'',txtaddress:'',txtunit:'',txtcity:'',txtzipcode:'',txtManufacturerExistingUnit:'',txtManufacturerNewUnit:'',txtSeerEerExisting:'',txtSeerEerNew:'',txtPackageHeatPumpModeExisting:'',txtPackageHeatPumpModeNew:'',txtCondensingUnitModelExisting:'',txtCondensingUnitModelNew:'',txtAHUModelExisting:'',txtAHUModelNew:'',txtModelExisting:'',txtModelNew:'',txtKWStripHeatExisting:'',txtKWStripHeatNew:'',MinimumCircuitAmpExisting_CU:'',MinimumCircuitAmpExisting_AHUPKG:'',MinimumCircuitAmpNew_CU:'',MinimumCircuitAmpNew_AHUPKG:'',MaxOvercurrentProExisting_CU:'',MaxOvercurrentProExisting_AHUPKG:'',MaxOvercurrentProNew_CU:'',MaxOvercurrentProNew_AHUPKG:'',SizeofDisconnectNew_CU:'',SizeofDisconnectNew_AHUPKG:'',SizeofDisconnectExisting_CU:'',SizeofDisconnectExisting_AHUPKG:'',Willanewstand:'',Willaductsmoke:'',Istheduct:'',WilltheAClocation:'',txtCompanyName:'',txtflstate:''};
   }
   toggleMinimumCircuitAmpExisting_CU = (value) => {
      this.setState({MinimumCircuitAmpExisting_CU: value})
   }
   toggleMinimumCircuitAmpExisting_AHUPKG = (value) => {
      this.setState({MinimumCircuitAmpExisting_AHUPKG: value})
   }
   toggleMinimumCircuitAmpNew_CU = (value) => {
      this.setState({MinimumCircuitAmpNew_CU: value})
   }
   toggleMinimumCircuitAmpNew_AHUPKG = (value) => {
      this.setState({MinimumCircuitAmpNew_AHUPKG: value})
   }
   toggleMaxOvercurrentProExisting_CU = (value) => {
      this.setState({MaxOvercurrentProExisting_CU: value})
   }
   toggleMaxOvercurrentProExisting_AHUPKG = (value) => {
      this.setState({MaxOvercurrentProExisting_AHUPKG: value})
   }
   toggleMaxOvercurrentProNew_CU = (value) => {
      this.setState({MaxOvercurrentProNew_CU: value})
   }
   toggleMaxOvercurrentProNew_AHUPKG = (value) => {
      this.setState({MaxOvercurrentProNew_AHUPKG: value})
   }
   toggleSizeofDisconnectNew_CU = (value) => {
      this.setState({SizeofDisconnectNew_CU: value})
   }
   toggleSizeofDisconnectNew_AHUPKG = (value) => {
      this.setState({SizeofDisconnectNew_AHUPKG: value})
   }
   toggleSizeofDisconnectExisting_CU = (value) => {
      this.setState({SizeofDisconnectExisting_CU: value})
   }
   toggleSizeofDisconnectExisting_AHUPKG = (value) => {
      this.setState({SizeofDisconnectExisting_AHUPKG: value})
   }
   toggleWillanewstand = (value) => {
      this.setState({Willanewstand: value})
   }
   toggleWillaductsmoke = (value) => {
      this.setState({Willaductsmoke: value})
   }
   toggleIstheduct = (value) => {
      this.setState({Istheduct: value})
   }
   toggleWilltheAClocation = (value) => {
      this.setState({WilltheAClocation: value})
   }

   callSignup = async () => {
      this.setState({isShowingLoader: true});
      try{
         console.log(this.state.job_name);
         console.log(this.state.MinimumCircuitAmpExisting_CU);
         console.log(this.state.MinimumCircuitAmpExisting_AHUPKG);
         const formData = new FormData();
         formData.append('method', 'insertDatachange');
         formData.append('job_name', this.state.job_name);
         formData.append('txtaddress', this.state.txtaddress);
         formData.append('txtunit', this.state.txtunit);
         formData.append('txtcity', this.state.txtcity);
         formData.append('txtzipcode', this.state.txtzipcode);
         formData.append('txtManufacturerExistingUnit', this.state.txtManufacturerExistingUnit);
         formData.append('txtManufacturerNewUnit', this.state.txtManufacturerNewUnit);
         formData.append('txtSeerEerExisting', this.state.txtSeerEerExisting);
         formData.append('txtSeerEerNew', this.state.txtSeerEerNew);
         formData.append('txtPackageHeatPumpModeExisting', this.state.txtPackageHeatPumpModeExisting);
         formData.append('txtPackageHeatPumpModeNew', this.state.txtPackageHeatPumpModeNew);
         formData.append('txtCondensingUnitModelExisting', this.state.txtCondensingUnitModelExisting);
         formData.append('txtCondensingUnitModelNew', this.state.txtCondensingUnitModelNew);
         formData.append('txtAHUModelExisting', this.state.txtAHUModelExisting);
         formData.append('txtAHUModelNew', this.state.txtAHUModelNew);
         formData.append('txtModelExisting', this.state.txtModelExisting);

         formData.append('txtModelNew', this.state.txtModelNew);
         formData.append('txtKWStripHeatExisting', this.state.txtKWStripHeatExisting);
         formData.append('txtKWStripHeatNew', this.state.txtKWStripHeatNew);
         formData.append('MinimumCircuitAmpExisting_CU', this.state.MinimumCircuitAmpExisting_CU);
         formData.append('MinimumCircuitAmpExisting_AHUPKG', this.state.MinimumCircuitAmpExisting_AHUPKG);
         formData.append('MinimumCircuitAmpNew_CU', this.state.MinimumCircuitAmpNew_CU);

         formData.append('MinimumCircuitAmpNew_AHUPKG', this.state.MinimumCircuitAmpNew_AHUPKG);
         formData.append('MaxOvercurrentProExisting_CU', this.state.MaxOvercurrentProExisting_CU);
         formData.append('MaxOvercurrentProExisting_AHUPKG', this.state.MaxOvercurrentProExisting_AHUPKG);
         formData.append('MaxOvercurrentProNew_CU', this.state.MaxOvercurrentProNew_CU);
         formData.append('MaxOvercurrentProNew_AHUPKG', this.state.MaxOvercurrentProNew_AHUPKG);
         formData.append('SizeofDisconnectNew_CU', this.state.SizeofDisconnectNew_CU);
         formData.append('SizeofDisconnectNew_AHUPKG', this.state.SizeofDisconnectNew_AHUPKG);

         formData.append('SizeofDisconnectExisting_CU', this.state.SizeofDisconnectExisting_CU);
         formData.append('SizeofDisconnectExisting_AHUPKG', this.state.SizeofDisconnectExisting_AHUPKG);
         formData.append('Willanewstand', this.state.Willanewstand);
         formData.append('Willaductsmoke', this.state.Willaductsmoke);
         formData.append('Istheduct', this.state.Istheduct);

         formData.append('WilltheAClocation', this.state.WilltheAClocation);
         formData.append('txtCompanyName', this.state.txtCompanyName);
         formData.append('txtflstate', this.state.txtflstate);

         axios({
           url    : 'https://miamidata.com/mvpapi/webservices.php',
           method : 'POST',
           data   : formData,
           headers: {
                  Accept: 'application/json',
                  'Content-Type': 'multipart/form-data'
               }
            })
            .then(function (response) {
                  //console.log("response :", response);
                  //console.log("responseid :", response.data.userid);
                  //this.setState({ articleId: response.data.id });
                  Alert.alert(
                     'Message',
                     response.data.message,
                     [
                        {text: 'OK', onPress: () => ''},
                     ],
                     {cancelable: false},
                  )   
            })
            .catch(function (error) {
                  console.log("error from image :");
            })
      } catch (error) {
          console.log(error);
          this.setState({isShowingLoader: false});
          Alert.alert(
              'Error',
              'Something went wrong!',
              [
              {text: 'OK', onPress: () => console.log('OK Pressed')},
              ],
              {cancelable: false},
          )
      }
 }
   render() {
      

      return (
         <ScrollView>
         <View style={styles.container}>
            
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(job_name) => this.setState({job_name})}  
                     placeholder="Job Name"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.job_name.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtaddress) => this.setState({txtaddress})}  
                     placeholder="Address"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtaddress.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtunit) => this.setState({txtunit})}  
                     placeholder="Unit#"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtunit.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtcity) => this.setState({txtcity})}  
                     placeholder="City"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtcity.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtzipcode) => this.setState({txtzipcode})}  
                     placeholder="Zipcode"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtzipcode.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtManufacturerExistingUnit) => this.setState({txtManufacturerExistingUnit})}  
                     placeholder="Manufacturer Existing"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtManufacturerExistingUnit.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtManufacturerNewUnit) => this.setState({txtManufacturerNewUnit})}  
                     placeholder="Manufacturer New"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtManufacturerNewUnit.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtSeerEerExisting) => this.setState({txtSeerEerExisting})}  
                     placeholder="SEER (2)/EER (3) Existing"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtSeerEerExisting.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtSeerEerNew) => this.setState({txtSeerEerNew})}  
                     placeholder="SEER (2)/EER (3) New"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtSeerEerNew.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtPackageHeatPumpModeExisting) => this.setState({txtPackageHeatPumpModeExisting})}  
                     placeholder="Package/Heat Pump Model Existing #"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtPackageHeatPumpModeExisting.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtPackageHeatPumpModeNew) => this.setState({txtPackageHeatPumpModeNew})}  
                     placeholder="Package/Heat Pump Model New #"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtPackageHeatPumpModeNew.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtCondensingUnitModelExisting) => this.setState({txtCondensingUnitModelExisting})}  
                     placeholder="Condensing Unit Model Existing #"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtCondensingUnitModelExisting.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtCondensingUnitModelNew) => this.setState({txtCondensingUnitModelNew})}  
                     placeholder="Condensing Unit Model New #"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtCondensingUnitModelNew.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtAHUModelExisting) => this.setState({txtAHUModelExisting})}  
                     placeholder="AHU Model Existing #"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtAHUModelExisting.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtAHUModelNew) => this.setState({txtAHUModelNew})}  
                     placeholder="AHU Model New #"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtAHUModelNew.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtModelExisting) => this.setState({txtModelExisting})}  
                     placeholder="Model Existing #"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtModelExisting.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtModelNew) => this.setState({txtModelNew})}  
                     placeholder="Model New #"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtModelNew.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtKWStripHeatExisting) => this.setState({txtKWStripHeatExisting})}  
                     placeholder="KW Strip Heat Existing"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtKWStripHeatExisting.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtKWStripHeatNew) => this.setState({txtKWStripHeatNew})}  
                     placeholder="KW Strip Heat New"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtKWStripHeatNew.focus()}
                  />
            </View>
            
            <Text style={styles.clstitletext}>
               Minimum Circuit Amp Existing
            </Text>
            <Text style={styles.clscheckboxlabel}>
               <Switch 
                  onValueChange={this.toggleMinimumCircuitAmpExisting_CU}
                  value={this.state.MinimumCircuitAmpExisting_CU}
               />
               c/u
            </Text>
            <Text style={styles.clscheckboxlabel}>  
               <Switch 
                  onValueChange={this.toggleMinimumCircuitAmpExisting_AHUPKG}
                  value={this.state.MinimumCircuitAmpExisting_AHUPKG}
               />
               ahu/pkg
            </Text>
            <Text style={styles.clstitletext}>
               Minimum Circuit Amp New
            </Text>
            <Text style={styles.clscheckboxlabel}>
               <Switch 
                  onValueChange={this.toggleMinimumCircuitAmpNew_CU}
                  value={this.state.MinimumCircuitAmpNew_CU}
               />
               c/u
            </Text>
            <Text style={styles.clscheckboxlabel}>  
               <Switch 
                  onValueChange={this.toggleMinimumCircuitAmpNew_AHUPKG}
                  value={this.state.MinimumCircuitAmpNew_AHUPKG}
               />
               ahu/pkg
            </Text>
            <Text style={styles.clstitletext}>
               Maximum Overcurrent Protection Existing
            </Text>
            <Text style={styles.clscheckboxlabel}>
               <Switch 
                  onValueChange={this.toggleMaxOvercurrentProExisting_CU}
                  value={this.state.MaxOvercurrentProExisting_CU}
               />
               c/u
            </Text>
            <Text style={styles.clscheckboxlabel}>  
               <Switch 
                  onValueChange={this.toggleMaxOvercurrentProExisting_AHUPKG}
                  value={this.state.MaxOvercurrentProExisting_AHUPKG}
               />
               ahu/pkg
            </Text>
            <Text style={styles.clstitletext}>
               Maximum Overcurrent Protection New
            </Text>
            <Text style={styles.clscheckboxlabel}>
               <Switch 
                  onValueChange={this.toggleMaxOvercurrentProNew_CU}
                  value={this.state.MaxOvercurrentProNew_CU}
               />
               c/u
            </Text>
            <Text style={styles.clscheckboxlabel}>  
               <Switch 
                  onValueChange={this.toggleMaxOvercurrentProNew_AHUPKG}
                  value={this.state.MaxOvercurrentProNew_AHUPKG}
               />
               ahu/pkg
            </Text>
            <Text style={styles.clstitletext}>
               Size of Disconnect Existing
            </Text>
            <Text style={styles.clscheckboxlabel}>
               <Switch 
                  onValueChange={this.toggleSizeofDisconnectNew_CU}
                  value={this.state.SizeofDisconnectNew_CU}
               />
               c/u
            </Text>
            <Text style={styles.clscheckboxlabel}>  
               <Switch 
                  onValueChange={this.toggleSizeofDisconnectNew_AHUPKG}
                  value={this.state.SizeofDisconnectNew_AHUPKG}
               />
               ahu/pkg
            </Text>
            <Text style={styles.clstitletext}>
               Size of Disconnect New
            </Text>
            <Text style={styles.clscheckboxlabel}>
               <Switch 
                  onValueChange={this.toggleSizeofDisconnectExisting_CU}
                  value={this.state.SizeofDisconnectExisting_CU}
               />
               c/u
            </Text>
            <Text style={styles.clscheckboxlabel}>  
               <Switch 
                  onValueChange={this.toggleSizeofDisconnectExisting_AHUPKG}
                  value={this.state.SizeofDisconnectExisting_AHUPKG}
               />
               ahu/pkg
            </Text>
            <Text style={styles.clscheckboxlabel}>  
               <Switch 
                  onValueChange={this.toggleWillanewstand}
                  value={this.state.Willanewstand}
               />
               Will a new stand, curb or curb adapter be installed?
            </Text>
            <Text style={styles.clscheckboxlabel}>  
               <Switch 
                  onValueChange={this.toggleWillaductsmoke}
                  value={this.state.Willaductsmoke}
               />
               Will a duct smoke detector be installed or reconnected?
            </Text>
            <Text style={styles.clscheckboxlabel}>  
               <Switch 
                  onValueChange={this.toggleIstheduct}
                  value={this.state.Istheduct}
               />
               Is the duct s/d connected to an Fire Alarm Panel?
            </Text>
            <Text style={styles.clscheckboxlabel}>  
               <Switch 
                  onValueChange={this.toggleWilltheAClocation}
                  value={this.state.WilltheAClocation}
               />
               Will the A/C location will be the same?
            </Text>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtCompanyName) => this.setState({txtCompanyName})}  
                     placeholder="Company Name"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtCompanyName.focus()}
                  />
            </View>
            <View style={styles.textboxwrraper}>
               <TextInput style={styles.inputBox} 
                     onChangeText={(txtflstate) => this.setState({txtflstate})}  
                     placeholder="FL State or Co. License #"
                     placeholderTextColor = "#ffffff"
                     selectionColor="#fff"
                     keyboardType="default"
                     onSubmitEditing={()=> this.txtflstate.focus()}
                  />
            </View>
            <TouchableOpacity onPress={this.callSignup} style={styles.button}>
               <Text style={styles.buttonText}>Submit</Text>
            </TouchableOpacity>
         </View>
         </ScrollView>	
         
      )
   }
}
const styles = StyleSheet.create({
   container : {
      backgroundColor:'#455a64',
      alignItems:'center',
      justifyContent :'center'
   },
   inputBox: {
     width:300,
     height:45,
     backgroundColor:'rgba(255, 255,255,0.2)',
     borderRadius: 15,
     paddingHorizontal:12,
     fontSize:16,
     color:'#ffffff',
     marginVertical: 10
   },
   PickerBox:{
     width:300,
     height:45,
     backgroundColor:'rgba(255, 255,255,0.2)',
     fontSize:16,
     color:'#ffffff',
   },
   button: {
     width:300,
     backgroundColor:'#1c313a',
      borderRadius: 25,
       marginVertical: 10,
       paddingVertical: 13
   },
   buttonText: {
     fontSize:16,
     fontWeight:'500',
     color:'#ffffff',
     textAlign:'center'
   },
   clstitletext:{
      width:300,
      fontSize: 20,
      fontWeight: "bold",
      color:'#FFFFFF',
   },
   clscheckboxlabel:{
      width:300,
      fontSize: 18,
      color:'#FFFFFF',
      padding:"2%"
   },
   datepickerwarraper:{
      marginTop:"3%",
      marginBottom:"3%",
      color:'#FFFFFF',
   },
   datepickerinput:{
      width:300,
      color:'#FFFFFF',
   }
   
 });